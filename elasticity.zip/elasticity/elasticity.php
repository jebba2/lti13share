<?php
require_once __DIR__ . '/../../../vendor/autoload.php';
require_once __DIR__ . '/../../../platformReg/platformRegistration.php';

use \IMSGlobal\LTI;

$launch = LTI\LTI_Message_Launch::from_cache($_GET['launchid'], new platformRegistration());

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--  <title>Fabric.js Introduction</title>-->
    <meta charset="UTF-8" />

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--  <script src="https://code.highcharts.com/highcharts.js"></script>-->

    <style>

        .fieldset {
            position: relative;
            border: 4px solid #0071CE;
            padding: 10px;
        }

        .fieldset h1 {
            position: absolute;
            top: 0;
            font-size: 18px;
            color: white;
            line-height: 1;
            margin: -19px 0 0; /* half of font-size */
            background: #0071CE;
            padding: 10px 10px 10px 10px;
        }


        body {
            background-color: #EEEEEE !important;
        }
        .table {
            padding: 1px !important;
            border-collapse: collapse !important;
        'border: 1px solid #ccc;
        'border: transparent;
        }
        .table > td{
        'padding: 1px !important;
        'border: transparent;
        'border-bottom: 0 !important;
        'border: 1px solid #ccc;
        }
        .table tr {
        'margin: 5px !important;
        'border: 1px solid transparent !important;
        padding: 1px !important;
        'border: none !important;
            /*border-bottom: 0 !important;*/
        }

        .table-hover tbody tr:hover td, .table-hover tbody tr:hover th {
            background-color: #D9E5F0;
        }


        #feedback_div{
            background-color: #CCCCCC;
        }
        .visible{
            visibility: visible;
        }
        .invisible{
            visibility: hidden;
        }
        caption {
            caption-side:top;
        }
        table {
            /*display: flex;*/
            /*flex-direction: column;*/
            /*align-items: center;*/
            /*border: red solid*/
            table-layout: fixed; width: 100%;
        }
        /*input[type=number]{*/
        /*    width: 150px;*/
        /*}*/
        .currencyinput {
            border: 1px inset #ccc;
        }
        .currencyinput input {
            border: 0;
        }
        .feedback {
            width: 50px;
            height: 50px;
            font-size: 25px;
            font-weight: bold;
        }
        .correct{
            color: green;
        }
        .incorrect{
            color: red;
        }
        .vert-center{
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }
        span.currency, div.currency{
            position:relative;
        }
        span.currency input, div.currency input{
            padding-left: 15px;
        }
        div.currency:after{
            position: absolute;
            left: 6px;
            top: 2px;
            content: '$';
        }


        /*span[id^="jqxWidget"]*/
        /*{*/
        /*    color: transparent !important;*/
        /*}*/
        .green {
            color: black;
            /*background-color: #ddeedc !important;*/
            background-color: #eef6ed !important;
        }
        .yellow {
            color: black;
            /*background-color: blue;*/
        }
        .red {
            color: black;
            /*background-color: #ffcccb !important;*/
            background-color: #ffe5e5 !important;
            /*text-decoration: line-through;*/
        }
        .editable {
            background-color: #FFFFE0	 !important;
        }
        [role="columnheader"] {
            /*background-color: #97CAEB !important;*/
        }
        /*change button to gsu blue*/
        .btn-primary, .btn-primary:hover, .btn-primary:active, .btn-primary:visited {
            background-color: #0071CE; !important;
            border-color: #0071CE; !important;;
        }
        .center_container {
            display: none;
            font-size: 18px;
            font-weight: bold;
            position: absolute;
            top: 50%;
            left: 50%;
            -moz-transform: translateX(-50%) translateY(-50%);
            -webkit-transform: translateX(-50%) translateY(-50%);
            transform: translateX(-50%) translateY(-50%);
        }
        /*.jqx-widget .jqx-grid-column-header {*/
        /*    white-space:normal !important;*/
        /*}*/
        input, select{
            height: 28px;
        }
        input{
            width: 100px !important;
        }

        li{
            /*list-style-type: circle;*/
        }

        .table-active{
            background-color: #D9E5F0 !important;
        }

        td.selected_cell {
            outline: solid 2px #0071CE;
            outline-offset: -2px;
        }

        /*table.table-bordered > tbody > tr > td{*/
        /*    margin: -1px 0 0;*/
        /*    border-top:2px 1px 1px 1px solid blue;*/
        /*}*/

    </style>

</head>

<body>
<br><br>
<div class="container">
    <!--<div class col-xs-6>-->
    <section class="fieldset p-4">
        <h1><span id="title"></span></h1>
        <p> <span id="question_info"></span></p>
        <div class="row" id="question_div">
            <div id="problem_setup" class="col-12">
<!--                &lt;!&ndash;        <h2 class="sub-header">Subtitle</h2>&ndash;&gt;-->
<!--                <table id="myTable" class="table table-hover text-center">-->
<!--                    <thead></thead>-->
<!--                    <tbody></tbody>-->
<!--                </table>-->
            </div>
        </div>
    </section>

    <br>

    <p class="p-4" id="directions">
        <span style="font-weight: bold">Directions:</span> Answer the questions above based on the information provided.
    </p>

    <div class="d-flex justify-content-center">
        <button id="submit" class="btn btn-primary" disabled>Check Answers</button>
        <button id="btn_continue" class="btn btn-primary invisible">Continue</button>
    </div>
    <div class="d-flex justify-content-center mt-4">
        <div class="btn-toolbar">
            <button id="btn_repeat" class="btn btn-primary invisible me-4">Try again</button>
            <button id="btn_finished" class="btn btn-primary invisible float-end">Submit to gradebook</button>
        </div>
    </div>
    <div class="center_container">FINISHED WITH ACTIVITY</div>

</div>


<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>

</body>
</html>

<script src="./helper_functions.js"></script>
<script src="./pipwerks_SCORM_API_wrapper.js"></script>
<script>
    //QUESTION_SCENARIO_TOKEN           //
    // let question_scenario = '';
    //QUESTION_TYPE_TOKEN               // 'demand' and 'supply'
    let question_type = 'demand';
    //SCORING_MODE_TOKEN
    let scoring_mode = 'practice';
    //ELASTICITY_TYPE_TOKEN        // 'price', 'other', 'total'  ('other' is crossprice & income combined; 'total' is total expentitures/revenue),
    let elasticity_type = 'total';


    let demand_supply;
    let demanded_supplied;
    let consumer_producer;
    let pay_accept;
    let buy_sell;
    let benefits_costs;

    if (question_type == 'demand'){
        demand_supply = 'Demand';
        demanded_supplied = 'Demanded';
        consumer_producer = 'Consumer';
        pay_accept = 'Pay';
        buy_sell = 'buy';
        benefits_costs = 'Benefits'
        buyer_seller = 'Buyer';
    }
    if (question_type == 'supply'){
        demand_supply = 'Supply';
        demanded_supplied = 'Supplied';
        consumer_producer = 'Producer';
        pay_accept = 'Accept';
        buy_sell = 'sell';
        benefits_costs = 'Costs';
        buyer_seller = 'Seller';
    }

    let title_text
    if (elasticity_type == 'price'){
        // capitalize first letter of elasticity_type variable
        title_text = elasticity_type.charAt(0).toUpperCase() + elasticity_type.slice(1) + " Elasticity of " + demand_supply;
    } else if (elasticity_type == 'other'){
        title_text = 'Cross-Price and Income Elasticities of Demand';
    } else if (elasticity_type == 'total'){
        title_text = 'Price Elasticity of Demand, Total Revenue and Total Expenditures';
    }

    let activity_info = {
        title: title_text,
        text: '',
    };

    let stage;
    let num_stages;

    // define a subpartition of a stage, to allow sequencing within a given stage
    let substage;

    let version;

    //declare data that will represent the problem

    let selected_questions;
    let p;
    let q;
    let qq;

    // declare an array that will contain responses
    let responses = [];

    // declare an array that will contain scores
    let scores = [];

    let quiz_versions = [];

    let table_active = false;

    // stuff for SCORM
    let session_start_time;
    let stage_start_time;

    let student_id;
    let student_name;


    // ################################################################################
    // ########## M4/? Quiz part ? Price Elasticity of Demand/Supply
    // ################################################################################
    // ###Cross-Price Elasticity questions:
    let price_questions = [
        [['When the price changes by [x]%, the quantity '+ demanded_supplied.toLowerCase() +' changes by [y]% for a particular good.',
            'What is the numerical value of the price elasticity of ' + demand_supply.toLowerCase() + '?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'In this case, we say that ' + demand_supply.toLowerCase() + ' is:',
            1],
            ['Suppose that the quantity '+ demanded_supplied.toLowerCase() +' changes by [y]% when the price changes by [x]% for a particular good.',
                'What is the numerical value of the price elasticity of ' + demand_supply.toLowerCase() + '?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'In this case, we say that ' + demand_supply.toLowerCase() + ' is:',
            2],
        ['When the price increases by [x]%, the quantity '+ demanded_supplied.toLowerCase() +' increases by [y]% for a particular good.',
            'What is the numerical value of the price elasticity of ' + demand_supply.toLowerCase() + '?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'In this case, we say that ' + demand_supply.toLowerCase() + ' is:',
            3],
            ['Suppose that the quantity '+ demanded_supplied.toLowerCase() +' increases by [y]% when the price increases by [x]% for a particular good.',
                'What is the numerical value of the price elasticity of ' + demand_supply.toLowerCase() + '?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'In this case, we say that ' + demand_supply.toLowerCase() + ' is:',
            4],
        ['When the price decreases by [x]%, the quantity '+ demanded_supplied.toLowerCase() +' decreases by [y]% for a particular good.',
            'What is the numerical value of the price elasticity of ' + demand_supply.toLowerCase() + '?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'In this case, we say that ' + demand_supply.toLowerCase() + ' is:',
            5],
            ['Suppose that the quantity '+ demanded_supplied.toLowerCase() +' decreases by [y]% when the price decreases by [x]% for a particular good.',
                'What is the numerical value of the price elasticity of ' + demand_supply.toLowerCase() + '?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'In this case, we say that ' + demand_supply.toLowerCase() + ' is:',
            6],]
    ]



    // ################################################################################
    // ########## M4 Quiz part 8 Interacting with Other Demand Elasticities
    // ################################################################################
    // ###Cross-Price Elasticity questions:
    //     #Pool 1 – substitutes:
    let other_questions = [[['When the price of Good A increases by [x]%, the quantity demanded of Good B increases by [y]%.',
                'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'Good A and Good B are most likely [other select plural]',
                1],
                ['Suppose that the quantity demanded of Good B increases by [y]% when the price of Good A increases by [x]%.',
                    'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                    'Good A and Good B are most likely [other select plural]',
                2],
                ['When the price of Good A decreases by [x]%, the quantity demanded of Good B decreases by [y]%.',
                    'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                    'Good A and Good B are most likely [other select plural]',
                3],
                ['Suppose that the quantity demanded of Good B decreases by [y]% when the price of Good A decreases by [x]%.',
                    'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                    'Good A and Good B are most likely [other select plural]',
                4],
            ],
            // #Pool 2 – complements :
        [['When the price of Good A increases by [x]%, the quantity demanded of Good B decreases by [y]%.',
            'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'Good A and Good B are most likely [other select plural]',
            5],
            ['Suppose that the quantity demanded of Good B increases by [y]% when the price of Good A decreases by [x]%.',
                'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'Good A and Good B are most likely [other select plural]',
            6],
            ['When the price of Good A decreases by [x]%, the quantity demanded of Good B increases by [y]%.',
                'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'Good A and Good B are most likely [other select plural]',
            7],
            ['Suppose that the quantity demanded of Good B decreases by [y]% when the price of Good A increases by [x]%.',
                'What is the numerical value of the cross-price elasticity between these goods?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'Good A and Good B are most likely [other select plural]',
            8],
        ],

    // ###Income Elasticity questions:
    //     #Pool 1 – normal:
        [['When a consumer’s income increases by [x]%, the quantity demanded of Good A increases by [y]%.',
            'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'We know that Good A is a(n) [other select singular]',
            9],
            ['Suppose that the quantity demanded of Good A increases by [y]% when a consumer’s income increases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular]',
            10],
            ['When a consumer’s income decreases by [x]%, the quantity demanded of Good A decreases by [y]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular]',
            11],
            ['Suppose that the quantity demanded of Good A decreases by [y]% when a consumer’s income decreases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular]',
            12],
        ],
            // #Pool 2 – inferior:
        [['When a consumer’s income increases by [x]%, the quantity demanded of Good A decreases by [y]%.',
            'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'We know that Good A is a(n) [other select singular]',
            13],
            ['Suppose that the quantity demanded of Good A increases by [y]% when a consumer’s income decreases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular]',
            14],
            ['When a consumer’s income decreases by [x]%, the quantity demanded of Good A increases by [y]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular]',
            15],
            ['Suppose that the quantity demanded of Good A decreases by [y]% when a consumer’s income increases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular]',
            16]
        ],
            // #Pool 3 – necessity:
        [['When a consumer’s income increases by [x]%, the quantity demanded of Good A increases by [y]%.',
            'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'We know that Good A is a(n) [other select singular 2]',
            17],
            ['Suppose that the quantity demanded of Good A increases by [y]% when a consumer’s income increases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular 2]',
            18],
            ['When a consumer’s income decreases by [x]%, the quantity demanded of Good A decreases by [y]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular 2]',
            19],
            ['Suppose that the quantity demanded of Good A decreases by [y]% when a consumer’s income decreases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular 2]',
            20]
        ],
            // #Pool 4 –  luxury:
        [['When a consumer’s income increases by [x]%, the quantity demanded of Good A increases by [y]%.',
            'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
            'We know that Good A is a(n) [other select singular 2]',
            21],
            ['Suppose that the quantity demanded of Good A increases by [y]% when a consumer’s income increases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular 2]',
            22],
            ['When a consumer’s income decreases by [x]%, the quantity demanded of Good A decreases by [y]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular 2]',
            23],
            ['Suppose that the quantity demanded of Good A decreases by [y]% when a consumer’s income decreases by [x]%.',
                'What is the numerical value of the income elasticity?  Round your answer to one decimal place, and don’t forget to indicate the sign (positive or negative).',
                'We know that Good A is a(n) [other select singular 2]',
            24]
        ]]

    // ####################################################################################################
    // ########## M4 Quiz part 9 Examining Price Elasticity Demand and Total Revenue or Total Expenditures
    // ####################################################################################################
    // ###Inelastic demand: (randomly choose 1 from each pool)
    // #Pool 1:
    let total_questions = [
        [[,'If the price elasticity of demand is [e], the seller should [total_select_1] the price if they want to increase revenue.',
            1],
            [,'If the price elasticity of demand is [e], the seller should [total_select_2] the price if they want to increase revenue.',
            2],
            [,'To increase total revenue, the seller should [total_select_1] the price on a good with a price elasticity of demand equal to [e].',
            3],
            [,'To increase total revenue, the seller should [total_select_2] the price on a good with a price elasticity of demand equal to [e].',
            4],
            [,'When the price elasticity of demand is [e], if the seller [total_select_3] the price, they will see an increase in total revenue.',
            5],
            [,'When the price elasticity of demand is [e], if the seller [total_select_3] the price, they will see a decrease in total revenue.',
            6],
            [,'When the price elasticity of demand is [e], if the seller [total_select_4] the price, they will see an increase in total revenue.',
            7],
            [,'When the price elasticity of demand is [e], if the seller [total_select_4] the price, they will see a decrease in total revenue.',
            8],
            [,'Total expenditures will increase when the buyers see the price [total_select_5] on a good with a price elasticity of demand equal to [e].',
            9],
            [,'Total expenditures will decrease when the buyers see the price [total_select_5] on a good with a price elasticity of demand equal to [e].',
            10],
            [,'Total expenditures will increase when the buyers see the price [total_select_2] on a good with a price elasticity of demand equal to [e].',
            11],
            [,'Total expenditures will decrease when the buyers see the price [total_select_2] on a good with a price elasticity of demand equal to [e].',
            12],
        ],
            // #Pool 2:
        [[,'Total revenue fell from $[x] to $[y] when price fell from [a] to [b], therefore, demand must be [total_select_6].',
            13],
            [,'Total revenue decreased from $[x] to $[y] when price decreased from [a] to [b], therefore, demand must be [total_select_6].',
            14],
            [,'Decreasing the price from [a] to [b] causes total revenue to fall from $[x] to $[y], so demand must be [total_select_6].',
            15],
            [,'Lowering the price from [a] to [b] causes total revenue to decrease from $[x] to $[y], so demand must be [total_select_6].',
            16],
            [,'Total expenditures fell from $[x] to $[y] when price fell from [a] to [b], therefore, demand must be [total_select_6]',
            17],
            [,'Total expenditures decreased from $[x] to $[y] when price decreased from [a] to [b], therefore, demand must be [total_select_6].',
            18],
            [,'Decreasing the price from [a] to [b] causes total expenditures to fall from $[x] to $[y], so demand must be [total_select_6].',
            19],
            [,'Lowering the price from [a] to [b] causes total expenditures to decrease from $[x] to $[y], so demand must be [total_select_6].',
            20],
            [,'Total revenue rose from $[x] to $[y] when price rose from [a] to [b], therefore, demand must be [total_select_6].',
            21],
            [,'Total revenue increased from $[x] to $[y] when price increased from [a] to [b], therefore, demand must be [total_select_6].',
            22],
            [,'Increasing the price from [a] to [b] causes total revenue to rise from $[x] to $[y], so demand must be [total_select_6].',
            23],
            [,'Raising the price from [a] to [b] causes total revenue to increase from $[x] to $[y], so demand must be [total_select_6].',
            24],
            [,'Total expenditures rose from $[x] to $[y] when price rose from [a] to [b], therefore, demand must be [total_select_6].',
            25],
            [,'Total expenditures increased from $[x] to $[y] when price increased from [a] to [b], therefore, demand must be [total_select_6].',
            26],
            [,'Increasing the price from [a] to [b] causes total expenditures to rise from $[x] to $[y], so demand must be [total_select_6].',
            27],
            [,'Raising the price from [a] to [b] causes total expenditures to increase from $[x] to $[y], so demand must be [total_select_6].',
            28],
        ],

        // ###Elastic demand: (randomly choose 1 from each pool)
        // #Pool 1:
        [[,'If the price elasticity of demand is [e], the seller should [total_select_1] the price if they want to increase revenue.',
            29],
            [,'If the price elasticity of demand is [e], the seller should [total_select_2] the price if they want to increase revenue.',
            30],
            [,'To increase total revenue, the seller should [total_select_1] the price on a good with a price elasticity of demand equal to [e].',
            31],
            [,'To increase total revenue, the seller should [total_select_2] the price on a good with a price elasticity of demand equal to [e].',
            32],
            [,'When the price elasticity of demand is [e], if the seller [total_select_3] the price, they will see an increase in total revenue.',
            33],
            [,'When the price elasticity of demand is [e], if the seller [total_select_3] the price, they will see a decrease in total revenue.',
            34],
            [,'When the price elasticity of demand is [e], if the seller [total_select_4] the price, they will see an increase in total revenue.',
            35],
            [,'When the price elasticity of demand is [e], if the seller [total_select_4] the price, they will see a decrease in total revenue.',
            36],
            [,'Total expenditures will increase when the buyers see the price [total_select_5] on a good with a price elasticity of demand equal to [e].',
            37],
            [,'Total expenditures will decrease when the buyers see the price [total_select_5] on a good with a price elasticity of demand equal to [e].',
            38],
            [,'Total expenditures will increase when the buyers see the price [total_select_2] on a good with a price elasticity of demand equal to [e].',
            39],
            [,'Total expenditures will decrease when the buyers see the price [total_select_2] on a good with a price elasticity of demand equal to [e].',
            40],
        ],
            // #Pool 2:
        [[,'Total revenue fell from $[x] to $[y] when price rose from [a] to [b], therefore, demand must be [total_select_6].',
            41],
            [,'Total revenue decreased from $[x] to $[y] when price increased from [a] to [b], therefore, demand must be [total_select_6].',
            42],
            [,'Increasing the price from [a] to [b] causes total revenue to fall from $[x] to $[y], so demand must be [total_select_6].',
            43],
            [,'Raising the price from [a] to [b] causes total revenue to decrease from $[x] to $[y], so demand must be [total_select_6].',
            44],
            [,'Total expenditures fell from $[x] to $[y] when price rose from [a] to [b], therefore, demand must be [total_select_6].',
            45],
            [,'Total expenditures decreased from $[x] to $[y] when price increased from [a] to [b], therefore, demand must be [total_select_6].',
            46],
            [,'Increasing the price from [a] to [b] causes total expenditures to fall from $[x] to $[y], so demand must be [total_select_6].',
            47],
            [,'Raising the price from [a] to [b] causes total expenditures to decrease from $[x] to $[y], so demand must be [total_select_6].',
            48],
            [,'Total revenue rose from $[x] to $[y] when price fell from [a] to [b], therefore, demand must be [total_select_6].',
            49],
            [,'Total revenue increased from $[x] to $[y] when price decreased from [a] to [b], therefore, demand must be [total_select_6].',
            50],
            [,'Decreasing the price from [a] to [b] causes total revenue to rise from $[x] to $[y], so demand must be [total_select_6].',
            51],
            [,'Lowering the price from [a] to [b] causes total revenue to increase from $[x] to $[y], so demand must be [total_select_6].',
            52],
            [,'Total expenditures rose from $[x] to $[y] when price fell from [a] to [b], therefore, demand must be [total_select_6].',
            53],
            [,'Total expenditures increased from $[x] to $[y] when price decreased from [a] to [b], therefore, demand must be [total_select_6].',
            54],
            [,'Decreasing the price from [a] to [b] causes total expenditures to rise from $[x] to $[y], so demand must be [total_select_6].',
            55],
            [,'Lowering the price from [a] to [b] causes total expenditures to increase from $[x] to $[y], so demand must be [total_select_6].',
            56],
        ],

    // ###Unit Elastic demand: (randomly choose 1 from each pool)
    // #Pool 1:
    // let unitelastic_questions =
        [[,'When the price elasticity of demand is [e], the seller has [total_select_7] the price.',
            57],
            [,'When the price elasticity of demand is [e], regardless of how the seller changes the price, they will see [total_select_8] in total revenue.',
            58],
            [,'Total expenditures will [total_select_2] when the buyers see the price rise on a good with a price elasticity of demand equal to [e].',
            59],
            [,'Total expenditures will [total_select_2] when the buyers see the price fall on a good with a price elasticity of demand equal to [e].',
            60],
            [,'Total expenditures will [total_select_2] when the buyers see the price increase on a good with a price elasticity of demand equal to [e].',
            61],
            [,'Total expenditures will [total_select_2] when the buyers see the price decrease on a good with a price elasticity of demand equal to [e].',
            62],
        ],
            // #Pool 2:
        [[,'Total revenue remained the same when price rose from [a] to [b], therefore, demand must be [total_select_6].',
            63],
            [,'Total revenue remained the same when price increased from [a] to [b], therefore, demand must be [total_select_6].',
            64],
            [,'Increasing the price from [a] to [b] causes no change in total revenue, so demand must be [total_select_6].',
            65],
            [,'Raising the price from [a] to [b] no change in total revenue, so demand must be [total_select_6].',
            66],
            [,'Total expenditures remained unchanged when price rose from [a] to [b], therefore, demand must be [total_select_6].',
            67],
            [,'Total expenditures remained unchanged when price increased from [a] to [b], therefore, demand must be [total_select_6].',
            68],
            [,'Increasing the price from [a] to [b] causes no change in total expenditures, so demand must be [total_select_6].',
            69],
            [,'Raising the price from [a] to [b] causes no change in total expenditures, so demand must be [total_select_6].',
            70],
            [,'Total revenue remained the same when price fell from [a] to [b], therefore, demand must be [total_select_6].',
            71],
            [,'Total revenue remained the same when price decreased from [a] to [b], therefore, demand must be [total_select_6].',
            72],
            [,'Decreasing the price from [a] to [b] causes no change in total revenue, so demand must be [total_select_6].',
            73],
            [,'Lowering the price from [a] to [b] causes no change in total revenue, so demand must be [total_select_6].',
            74],
            [,'Total expenditures did not change when price fell from [a] to [b], therefore, demand must be [total_select_6].',
            75],
            [,'Total expenditures did not change when price decreased from [a] to [b], therefore, demand must be [total_select_6].',
            76],
            [,'Decreasing the price from [a] to [b] causes no change in total expenditures, so demand must be [total_select_6].',
            77],
            [,'Lowering the price from [a] to [b] causes no change in total expenditures, so demand must be [total_select_6].',
            78],
        ]
    ]

    function start_sequence(){

        // set some initial values
        responses = [];

        // Create question sequence

        qq = [];
        let target_questions;
        if (elasticity_type == 'price') {
            target_questions = deep_copy(price_questions);
        } else if (elasticity_type =='other'){
            target_questions = deep_copy(other_questions);
        } else if (elasticity_type == 'total'){
            target_questions = deep_copy(total_questions);
        }
        console.log('compare arrays');
        console.log(target_questions == total_questions);
        // target_questions = [...total_questions];
        console.log(target_questions === total_questions);



        if (elasticity_type=='other' && scoring_mode == 'quiz'){
            // pick two questions, one from the first 2 blocks, and the other the last 4 blocks
            // This will pick block 1 or 2
            let b = Math.floor(Math.random()*2);
            // and this will pick an element from the block
            let e = Math.floor(Math.random()*target_questions[b].length);
            qq.push(target_questions[b][e]);

            // now do similar for the second question
            b = Math.floor(Math.random()*4)+2;
            e = Math.floor(Math.random()*target_questions[b].length);
            qq.push(target_questions[b][e]);

        } else if (elasticity_type=='total' && scoring_mode == 'quiz'){
            // pick 3 questions, one from the first 2 blocks, next from next 2 blocks, and last from the final 2 blocks
            // This will pick block 1 or 2
            let b = Math.floor(Math.random()*2);
            // and this will pick an element from the block
            let e = Math.floor(Math.random()*target_questions[b].length);
            qq.push(target_questions[b][e]);

            // now do similar for the second question
            b = Math.floor(Math.random()*2)+2;
            e = Math.floor(Math.random()*target_questions[b].length);
            qq.push(target_questions[b][e]);

            // now do similar for the third question
            b = Math.floor(Math.random()*2)+4;
            e = Math.floor(Math.random()*target_questions[b].length);
            qq.push(target_questions[b][e]);
        } else {
            for (let i=0; i<target_questions.length; i++){
                let question = shuffle(target_questions[i])[0];
                qq.push(question);
            }
        }
        shuffle(qq);

        // change wording of questions from supply to demand context in price elasticity questions
        if (elasticity_type == 'price' && question_type == 'demand'){
            for (let i = 0; i < qq.length; i++){
                if (qq[i][0].includes('increas')){
                    qq[i][0] = qq[i][0].replace('increas', 'decreas');
                } else if (qq[i][0].includes('decreas')){
                    qq[i][0] = qq[i][0].replace('decreas', 'increas');
                }
            }
        }

        // stage 0 is intro screen; stage > 0 are decision screens
        stage = -1;
        substage = 0;
        score = 0;

        let questions_per_stage
        if (elasticity_type == 'price'){
            num_stages = 1;
            questions_per_stage = 2;
        } else if (elasticity_type == 'other'){
            if (scoring_mode == 'practice'){
                num_stages = 6;
                questions_per_stage = 2;
            } else if (scoring_mode == 'quiz'){
                num_stages = 2;
                questions_per_stage = 2;
            }
        } else if (elasticity_type == 'total'){
            if (scoring_mode == 'practice'){
                num_stages = 6;
                questions_per_stage = 1;
            } else if (scoring_mode == 'quiz'){
                num_stages = 3;
                questions_per_stage = 1;
            }
        }

        max_score = num_stages * questions_per_stage;

        pipwerks.SCORM.data.set('cmi.score.min', 0);
        if (scoring_mode == 'practice'){
            pipwerks.SCORM.data.set('cmi.score.max', 1);
        }
        if (scoring_mode == 'quiz'){
            pipwerks.SCORM.data.set('cmi.score.max', max_score);
        }
        draw_screen();
    }

    function block_participation() {

        $('section > div').hide();
        $('#directions').hide();
        $('#submit').hide();
        $('#submit').hide();
        $('#btn_continue').hide();

        $('#title').html(activity_info.title);

        let txt = '<br>You have already completed the quiz and may not retake it.';
        $('#question_info').html(txt);

        pipwerks.SCORM.data.set('cmi.exit', 'normal');
        pipwerks.SCORM.connection.terminate();
    }

    function intro() {
        // This is the content seen when the app first starts (or is repeated)

        $('section > div').hide();
        $('#directions').hide();
        $('#submit').hide();
        $('#btn_continue').removeClass('invisible');
        $('#btn_continue').addClass('visible');

        $('#question_info').html(get_intro_text(activity_info.title, scoring_mode, max_score, num_stages));
    }

    function ending() {

        if (scoring_mode=='quiz'){
            pipwerks.SCORM.data.set('cmi.exit', 'normal');
            pipwerks.SCORM.connection.terminate();
        }

        // This is the content seen after entering all questions. Primary purpose is to present total score.

        $('section > div').hide();
        $('#directions').hide();
        $('#submit').hide();


        $('#btn_finished').removeClass('invisible');
        $('#btn_finished').addClass('visible');

        if (scoring_mode == 'practice'){
            $('#btn_repeat').removeClass('invisible');
            $('#btn_repeat').addClass('visible');
        }

        $('#btn_continue').removeClass('visible');
        $('#btn_continue').addClass('invisible');

        let txt
        txt = '<p class="mt-4">';
        if (student_id != 'null' || student_name != 'null') {
            txt += 'Name: ' + student_name + '<br>';
            txt += 'ID: ' + student_id + '<br>';
            txt += '<br>';
        }
        txt += 'Your score on this activity is ';
        txt += score.toString()
        txt += " out of ";
        txt += max_score.toString();
        txt += ".</p>";

        if (scoring_mode == 'practice'){
            if (score == max_score){
                txt += "<p>Excellent work!</p>";
            } else {
                txt += "<p>Don't give up – you can do this! Keep practicing. Reach out to your instructor if you need assistance.</p>";
            }
        }
        $('#question_info').html(txt);
    }

    function draw_screen() {
        console.log('drawing screen');

        stage += 1;
        substage = 1;
        stage_start_time = new Date();

        console.log('stage='+stage);

        $('#title').text(activity_info.title);
        // $('#question').text(question.text);

        // This block handles the intro page.
        if (stage==0){
            intro();
            return;
        }
        $('#question_info').html('<p style="text-align:right">Page ' + stage.toString() + ' of ' + num_stages.toString() + '</p>');


        // This list is of the form [pair_1, pair_2, pair_3], and each pair is a list of the form [question_1, question_2].
        // We will randomly sample one question from each pair, and then shuffle.


        // questions initially have [x] [y] [select] tokens that must be replaced with appropriate stuff

        // Let price change percent take a random integer from 1 to 100.
        // Note that this rules out perfect inelasticity (i.e., p=0).
        p = Math.floor(Math.random()*100)+ 1;

        // Let's give a decent chance for perfect elasticity (i.e., q=0).
        q = shuffle([0, 7, 16, 25, 33, 47, 54, 68, 73, 91])[0];

        // We do not want elasticity to be 0 in cross-price or income problems
        // so if it is 0, then make it 80 (rather arbitrary, but it does fill a gap in the array above
        if (elasticity_type=='other'){
            q = (q==0) ? 80 : q;
        }


        // insure that necessities and luxuries have correct elasticity values
        if (elasticity_type=='other'){
            if ([17, 18, 19, 20].includes(qq[stage-1][3])){
                // necessity
                while (q/p > 1){
                    q = Math.floor(Math.random()*100)+ 1;
                    p = Math.floor(Math.random()*100)+ 1;
                }
            } else if ([21, 22, 23, 24].includes(qq[stage-1][3])){
                // luxury
                while (q/p < 1){
                    q = Math.floor(Math.random()*100)+ 1;
                    p = Math.floor(Math.random()*100)+ 1;
                }
            }
        }

        let e=1;



        if (elasticity_type == 'total'){

            let a;
            let b;

        // substitute numbers into questions.  Doing this inside here because this version uses different numbers than others.
        // In support of #77, swapping (price elasticity of demand variable) e to negative wherever it is in play below

            if (1 <= qq[stage-1][2] && qq[stage-1][2] <= 12 ){
                e = Math.random()*.98 + .01;
                e = Math.round( e * 100 ) / 100;
                e = -e;
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[e]', e.toString());
            }

            if (13 <= qq[stage-1][2] && qq[stage-1][2] <= 20 ){
                a = Math.floor(Math.random()*1000) + 1;
                b = Math.floor(Math.random()*1000) + 1;
                while (a <= b){
                    a = Math.floor(Math.random()*1000) + 1;
                    b = Math.floor(Math.random()*1000) + 1;
                }

                let x;
                let y;
                x = (Math.floor(Math.random()*1000)+1)*1000;
                y = (Math.floor(Math.random()*1000)+1)*1000;
                while (x <= y){
                    x = (Math.floor(Math.random()*1000)+1)*1000;
                    y = (Math.floor(Math.random()*1000)+1)*1000;
                }

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[a]', '$'+a.toString());
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[b]', '$'+b.toString());

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[x]', x.toLocaleString('en') );
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[y]', y.toLocaleString('en') );
            }

            if (21 <= qq[stage-1][2] && qq[stage-1][2] <= 28 ){
                a = Math.floor(Math.random()*1000) + 1;
                b = Math.floor(Math.random()*1000) + 1;
                while (a >= b){
                    a = Math.floor(Math.random()*1000) + 1;
                    b = Math.floor(Math.random()*1000) + 1;
                }
                let x;
                let y;
                x = (Math.floor(Math.random()*1000)+1)*1000;
                y = (Math.floor(Math.random()*1000)+1)*1000;
                while (x >= y){
                    x = (Math.floor(Math.random()*1000)+1)*1000;
                    y = (Math.floor(Math.random()*1000)+1)*1000;
                }

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[a]', '$'+a.toString());
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[b]', '$'+b.toString());

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[x]', x.toLocaleString('en') );
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[y]', y.toLocaleString('en') );
            }


            if (29 <= qq[stage-1][2] && qq[stage-1][2] <= 40 ){
                // need e greater than 1
                // while (e <= 1){
                    e = Math.floor(Math.random()*100) + 1;
                    // e = Math.round( e * 10 ) / 10;
                // }
                e = -e;
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[e]', e.toString());
            }

            if (41 <= qq[stage-1][2] && qq[stage-1][2] <= 48 ){
                a = Math.floor(Math.random()*1000) + 1;
                b = Math.floor(Math.random()*1000) + 1;
                while (a >= b){
                    a = Math.floor(Math.random()*1000) + 1;
                    b = Math.floor(Math.random()*1000) + 1;
                }

                x = (Math.floor(Math.random()*1000)+1)*1000;
                y = (Math.floor(Math.random()*1000)+1)*1000;
                while (x <= y){
                    x = (Math.floor(Math.random()*1000)+1)*1000;
                    y = (Math.floor(Math.random()*1000)+1)*1000;
                }

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[a]', '$'+a.toString());
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[b]', '$'+b.toString());

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[x]', x.toLocaleString('en') );
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[y]', y.toLocaleString('en') );
            }

            if (49 <= qq[stage-1][2] && qq[stage-1][2] <= 56 ){
                a = Math.floor(Math.random()*1000) + 1;
                b = Math.floor(Math.random()*1000) + 1;
                while (a <= b){
                    a = Math.floor(Math.random()*1000) + 1;
                    b = Math.floor(Math.random()*1000) + 1;
                }

                x = (Math.floor(Math.random()*1000)+1)*1000;
                y = (Math.floor(Math.random()*1000)+1)*1000;
                while (x >= y){
                    x = (Math.floor(Math.random()*1000)+1)*1000;
                    y = (Math.floor(Math.random()*1000)+1)*1000;
                }

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[a]', '$'+a.toString());
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[b]', '$'+b.toString());

                qq[stage-1][1] = qq[stage-1][1].replaceAll('[x]', x.toLocaleString('en') );
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[y]', y.toLocaleString('en') );
            }

            if (57 <= qq[stage-1][2] && qq[stage-1][2] <= 62 ){
                // need e greater than 1
                e = 1.0;
                e = -e;
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[e]', e.toString());
            }

            if (63 <= qq[stage-1][2] && qq[stage-1][2] <= 70 ){
                a = Math.floor(Math.random()*1000) + 1;
                b = Math.floor(Math.random()*1000) + 1;
                while (a >= b){
                    a = Math.floor(Math.random()*1000) + 1;
                    b = Math.floor(Math.random()*1000) + 1;
                }
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[a]', '$'+a.toString());
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[b]', '$'+b.toString());
            }

            if (71 <= qq[stage-1][2] && qq[stage-1][2] <= 78 ){
                a = Math.floor(Math.random()*1000) + 1;
                b = Math.floor(Math.random()*1000) + 1;
                while (a <= b){
                    a = Math.floor(Math.random()*1000) + 1;
                    b = Math.floor(Math.random()*1000) + 1;
                }
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[a]', '$'+a.toString());
                qq[stage-1][1] = qq[stage-1][1].replaceAll('[b]', '$'+b.toString());
            }

        } else {
            // not 'total'
            for (let i = 0; i < qq[stage-1].length-1; i++){
                qq[stage-1][i] = qq[stage-1][i].replaceAll('[x]', p.toString());
                qq[stage-1][i] = qq[stage-1][i].replaceAll('[y]', q.toString());
            }
        }




        let questions_header = qq[stage-1][0];

        // Insert question divs

        let q_divs = '';

        let t = '';

        if (elasticity_type != 'total'){
            t += '<div class="row substage1">';
            t += '    <div class="col-auto vert-center">';
            t +=          questions_header;
            t += '    </div>';
            t += '</div>';
            q_divs += t;
        }

        for (let q=1; q < qq[stage-1].length-1; q++){
            console.log('top of loop to create table');
            console.log('q='+q);

            let select_type;

            // do stuff here to parse question
            if (qq[stage-1][q].includes('[other select singular]')){
                select_type = 'other_singular';
                qq[stage-1][q] = qq[stage-1][q].replace('[other select singular]', "");
            }

            if (qq[stage-1][q].includes('[other select singular 2]')){
                select_type = 'other_singular_2';
                qq[stage-1][q] = qq[stage-1][q].replace('[other select singular 2]', "");
            }

            if (qq[stage-1][q].includes('[other select plural]')){
                select_type = 'other_plural';
                qq[stage-1][q] = qq[stage-1][q].replace('[other select plural]', "");
            }

            let text_a;
            let text_b;
            let token;
            


            token = '[total_select_1]'
            //  [raise/lower/not change]    #4
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_1';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
                // qq[stage-1][q] = qq[stage-1][q].replace('[other select plural]', "");
            }

            token = '[total_select_2]'
            //  [increase/decrease/not change]    #12
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_2';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            token = '[total_select_3]'
            //  [raises/lowers/does not change]    #4
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_3';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            token = '[total_select_4]'
            // [increases/decreases/does not change]     #4
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_4';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            token = '[total_select_5]'
            // [rise/fall/not change]   #4
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_5';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            token = '[total_select_6]'
            // [inelastic/unit elastic/elastic]     #48
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_6';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            token = '[total_select_7]'
            // [an incentive to raise/ an incentive to lower/no incentive to change]     #1
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_7';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            token = '[total_select_8]'
            // [a decrease/an increase/no change]     #1
            if (qq[stage-1][q].includes(token)){
                select_type = 'total_select_8';
                let txt = qq[stage-1][q].split(token);
                text_a = txt[0];
                text_b = txt[1];
            }

            console.log('SELECT LOGIC');
            console.log(select_type);

            console.log('q='+q);
            let t = '';


            if (elasticity_type == 'total'){
                t += '<div class="row" id="q' + q + '_div">';
                t += '  <div class="col-auto vert-center">';
                t += '      <label htmlFor="q' + q + '"><span id="q' + q + '_label">' + text_a + '</span></label>';
                t += '  </div>';
                t += '  <div class="col-auto vert-center">';
                if (select_type == 'total_select_1'){
                    //  [raise/lower/not change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">raise</option>';
                    t += '            <option value="down">lower</option>';
                    t += '            <option value="same">not change</option>';
                    t += '        </select>';
                    t += '      </div>';


                } else if (select_type == 'total_select_2'){
                    //  [increase/decrease/not change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">increase</option>';
                    t += '            <option value="down">decrease</option>';
                    t += '            <option value="same">not change</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                else if (select_type == 'total_select_3'){
                    //  [raises/lowers/does not change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">raises</option>';
                    t += '            <option value="down">lowers</option>';
                    t += '            <option value="same">does not change</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                else if (select_type == 'total_select_4'){
                    // [increases/decreases/does not change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">increases</option>';
                    t += '            <option value="down">decreases</option>';
                    t += '            <option value="same">does not change</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                else if (select_type == 'total_select_5'){
                    // [rise/fall/not change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">rise</option>';
                    t += '            <option value="down">fall</option>';
                    t += '            <option value="same">not change</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                else if (select_type == 'total_select_6'){
                    // [inelastic/unit elastic/elastic]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="inelastic">inelastic</option>';
                    t += '            <option value="unit elastic">unit elastic</option>';
                    t += '            <option value="elastic">elastic</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                else if (select_type == 'total_select_7'){
                    // [an incentive to raise/ an incentive to lower/no incentive to change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">an incentive to raise</option>';
                    t += '            <option value="down">an incentive to lower</option>';
                    t += '            <option value="same">no incentive to change</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                else if (select_type == 'total_select_8'){
                    // [an increase/a decrease/no change]
                    t += '      <div>';
                    t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                    t += '            <option value="">(select)</option>';
                    t += '            <option value="up">an increase</option>';
                    t += '            <option value="down">a decrease</option>';
                    t += '            <option value="same">no change</option>';
                    t += '        </select>';
                    t += '      </div>';
                }
                t += '  </div>';
                t += '  <div class="col-auto vert-center">';
                t += '      <span>' + text_b + '</span>';
                t += '  </div>';
                // t += '  <div class="col-auto vert-center">';

            } else {
                // This block handles 'price' and 'other' scenarios
                t += '<div class="row mt-4" id="q' + q + '_div">';
                t += '  <div class="col-auto vert-center">';
                t += '      <label htmlFor="q' + q + '"><span id="q' + q + '_label">' + qq[stage-1][q] + '</span></label>';
                t += '  </div>';
                t += '  <div class="col-auto vert-center">';
                if (q==1){

                    t += '      <div>';
                    t += '          <input class="target" required type="number" id="q' + q + '" name="q' + q + '" min="-1000">';
                    // min="0"
                    t += '      </div>';
                } else if (q==2){
                    if (elasticity_type == 'price') {
                        t += '      <div>';
                        t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                        t += '            <option value="">(select)</option>';
                        t += '            <option value="perfectly elastic">perfectly elastic</option>';
                        t += '            <option value="relatively elastic">relatively elastic</option>';
                        t += '            <option value="unit elastic">unit elastic</option>';
                        t += '            <option value="relatively inelastic">relatively inelastic</option>';
                        t += '            <option value="perfectly inelastic">perfectly inelastic</option>';
                        t += '        </select>';
                        t += '      </div>';
                    }
                    else if (elasticity_type == 'other'){
                        if (select_type == 'other_singular'){
                            t += '      <div>';
                            t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                            t += '            <option value="">(select)</option>';
                            t += '            <option value="substitute good">substitute good</option>';
                            t += '            <option value="complementary good">complementary good</option>';
                            t += '            <option value="normal good">normal good</option>';
                            t += '            <option value="inferior good">inferior good</option>';
                            t += '        </select>';
                            t += '      </div>';
                        }
                        else if (select_type == 'other_singular_2'){
                            t += '      <div>';
                            t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                            t += '            <option value="">(select)</option>';
                            t += '            <option value="substitute good">substitute good</option>';
                            t += '            <option value="complementary good">complementary good</option>';
                            t += '            <option value="necessity good">necessity good</option>';
                            t += '            <option value="luxury good">luxury good</option>';
                            t += '            <option value="inferior good">inferior good</option>';
                            t += '        </select>';
                            t += '      </div>';
                        }
                        else if (select_type == 'other_plural'){
                            t += '      <div>';
                            t += '        <select class="target" id="q' + q + '" name="q' + q + '">';
                            t += '            <option value="">(select)</option>';
                            t += '            <option value="substitutes">substitutes</option>';
                            t += '            <option value="complements">complements</option>';
                            t += '            <option value="normal">normal</option>';
                            t += '            <option value="inferior">inferior</option>';
                            t += '            <option value="luxuries">luxuries</option>';
                            t += '            <option value="necessities">necessities</option>';
                            t += '        </select>';
                            t += '      </div>';
                        }
                    }
                    // t += '      <div class="col-auto vert-center">';
                    // t += '          <span>&nbsp;.</span>';
                    // t += '      </div>';
                }
                t += '     </div>';
            }

            t += '     <div class="col-auto vert-center feedback" id="q' + q + '_grademark"></div>';
            t += '     <div class="col-auto vert-center" id="q' + q + '_feedback"></div>';
            t += '     <div class="col-auto vert-center" id="q' + q + '_hint"></div>';

            t += '</div>';
            q_divs += t;

        }

        $('#question_div').after(q_divs);

        let neg = elasticity_type == 'other' ? true : false;

        $('#directions').show();
        $('#submit').show();
        $('#btn_continue').removeClass('visible');
        $('#btn_continue').addClass('invisible');

        $('section > .substage1').show();

        $("[class*=substage]").not('.substage1').hide();


        $('section > #question_div').show();
        

        // The following function must be defined here because it handles events of elements that were just added above.

        let check_inputs = function () {
            console.log('CHECKING');
            let incomplete = false;
            let min_n = 1;
            let max_n = 2;
            let offset = 0;

            // if (change_mode == 'changes'){
            //     min_n = 1;
            //     max_n = 3;
            //     offset = (substage - 1) * 3;
            // }

            console.log('min:'+min_n);
            console.log('max:'+max_n);
            console.log('offset:'+offset);

            for (let i=min_n + offset; i<=max_n + offset; i++){
                console.log('i:'+i);

                    if (i==1) {
                        if( $('#q'+i).val() == "" ){
                            incomplete = true;
                            break;
                        }
                    }
                    else if (i == 2) {
                        if( $('#q'+i).val() == "" ){
                            incomplete = true;
                            break;
                        }
                    }
            }
            console.log(incomplete);
            $('#submit').prop('disabled', incomplete);
        };


        // The target class is assigned to all input and select html objects.
        // Had to do it this way to handle both types of objects with this single function.
        $(".target").on('input', check_inputs);


        //     <div className="col-auto vert-center" id="q1_feedback"></div>
        // </div>

        $('#directions').show();
        $('#submit').show();
        $('#btn_continue').removeClass('visible');
        $('#btn_continue').addClass('invisible');

        $('section > .substage1').show();

        $("[class*=substage]").not('.substage1').hide();


        $('section > #question_div').show();

    }

    // This function provides a feedback string for wrong answers based on question number
    function get_hint(q){
        let txt = "";
        // txt += '<li>'

        if (elasticity_type == 'price'){
            if ( q==0) {
                txt += 'Hint: The price elasticity of ' + demand_supply.toLowerCase() + ' is defined as the percentage change in quantity '+ demanded_supplied.toLowerCase() +' divided by the percentage change in price.  Be sure you are correctly rounding your answer to one decimal place, and that you have indicated the correct sign (positive or negative).';
            }
            if ( q==1) {
                txt += 'Hint: The degree of the elasticity depends upon the magnitude of the absolute value of the price elasticity of ' + demand_supply.toLowerCase() + ':'
                txt +=    '<ul>'
                txt +=      '<li>If the absolute value of the price elasticity of ' + demand_supply.toLowerCase() + ' is greater than 1, ' + demand_supply.toLowerCase() + ' is elastic.';
                txt +=      '<li>If the absolute value of the price elasticity of ' + demand_supply.toLowerCase() + ' is less than 1, ' + demand_supply.toLowerCase() + ' is inelastic.';
                txt +=      '<li>If the absolute value of the price elasticity of ' + demand_supply.toLowerCase() + ' is equal to 1, ' + demand_supply.toLowerCase() + ' is unit elastic.';
                txt +=      '<li>If the percentage change in price is zero, regardless of the percentage change in quantity '+ demanded_supplied.toLowerCase() +', ' + demand_supply.toLowerCase() + ' is perfectly elastic.';
                txt +=      '<li>If the percentage change in quantity '+ demanded_supplied.toLowerCase() +' is zero, regardless of the percentage change in price, ' + demand_supply.toLowerCase() + ' is inelastic.';
                txt +=    '</ul>'
            }
        }
        else if (elasticity_type == 'other'){

            if (qq[stage-1][3] < 9){
                if ( q==0) {
                    txt += 'Hint: The cross-price elasticity is defined as the percentage change in quantity demanded of one good divided by the percentage change in price of a different good.  Be sure you are correctly rounding your answer to one decimal place, and that you have indicated the correct sign (positive or negative).';
                }
                if ( q==1) {
                    txt += 'Hint: How goods are related depends on the sign of the cross-price elasticity between them:'
                    txt +=    '<ul>'
                    txt +=      '<li>If the cross-price elasticity between them is greater than 0, they are substitutes; the further from 0, the stronger substitutes they are.';
                    txt +=      '<li>If the cross-price elasticity between them is less than 0, they are complements; the further from 0, the stronger complements they are.';
                    txt +=      '<li>If the cross-price elasticity between them is equal to 0, they are unrelated.';
                    txt +=    '</ul>'
                }
            }
            else if (qq[stage-1][3] > 8){
                if ( q==0) {
                    txt += 'Hint: The income elasticity is defined as the percentage change in quantity demanded divided by the percentage change income.  Be sure you are correctly rounding your answer to one decimal place, and that you have indicated the correct sign (positive or negative). ';
                }
                if ( q==1) {
                    txt += 'Hint: How goods are classified depends on the sign and sometimes the magnitude of the income elasticity:'
                    txt +=    '<ul>'
                    txt +=      '<li>If the income elasticity is greater than 0, the good is normal.';
                    txt +=      '<li>If the income elasticity is greater than 0, but less than 1, the good is a necessity.';
                    txt +=      '<li>If the income elasticity is greater than 1, the good is a luxury.';
                    txt +=      '<li>If the income elasticity is less than 0, the good is inferior';
                    txt +=    '</ul>'
                }
            }
        } else if (elasticity_type == 'total'){
            if ( 1 <= qq[stage-1][2] && qq[stage-1][2] <= 28){
                txt = 'Hint: Total expenditures (by the buyers) equal price times quantity.  Expenditures by the buyers represent revenue to the seller.  Total revenue (for the seller) equals price times quantity.  Since sellers can only sell what buyers are willing and able to buy, this relationship is driven by demand.  The law of demand states that, all else equal, price and quantity demanded move in opposite directions.  If price increases, quantity demanded decreases, but by how much?  Which force is greater – the quantity effect or the price effect?  That’s what price elasticity of demand tells us. When demand is inelastic, consumers don’t respond much to price changes, so the quantity effect is less than the price effect.';
            }
            else if ( 29 <= qq[stage-1][2] && qq[stage-1][2] <= 56){
                txt = 'Hint: Total expenditures (by the buyers) equal price times quantity.  Expenditures by the buyers represent revenue to the seller.  Total revenue (for the seller) equals price times quantity.  Since sellers can only sell what buyers are willing and able to buy, this relationship is driven by demand.  The law of demand states that, all else equal, price and quantity demanded move in opposite directions.  If price increases, quantity demanded decreases, but by how much?  Which force is greater – the quantity effect or the price effect?  That’s what price elasticity of demand tells us. When demand is elastic, consumers respond a lot to price changes, so the quantity effect is greater than the price effect. ';
            }
            else if ( 57 <= qq[stage-1][2]){
                txt = 'Hint: Total expenditures (by the buyers) equal price times quantity.  Expenditures by the buyers represent revenue to the seller.  Total revenue (for the seller) equals price times quantity.  Since sellers can only sell what buyers are willing and able to buy, this relationship is driven by demand.  The law of demand states that, all else equal, price and quantity demanded move in opposite directions.  If price increases, quantity demanded decreases, but by how much?  Which force is greater – the quantity effect or the price effect?  That’s what price elasticity of demand tells us. When demand is unit elastic, the quantity effect is equal but opposite to the price effect. ';
            }
        }
        return txt;
    }

    function check_answers() {

        console.log ('checking answers');
        // gather responses from DOM elements and put into 'responses' array

        responses = [];


        let min_q = 1;
        let max_q = 2;
        let offset = 0;

        if (elasticity_type == 'total'){
            max_q = 1;
        }

        // if (change_mode == 'changes'){
        //     offset = (substage - 1) * 3;
        //     min_q = 1;
        //     max_q = 3;
        // }


        for (let i = min_q + offset; i<=max_q + offset; i++){
            let r
            if (elasticity_type == 'total'){
                r = $('#q'+i).val();
                responses.push([r]);
            } else {
                if ([1].includes(i)) {
                    // single number
                    r = $('#q'+i).val();
                    r = Number(r);
                    responses.push([r]);
                }
                else if ([2].includes(i)){
                    // response with select
                    r = $('#q'+i).val();
                    responses.push([r]);
                }
            }
            console.log('r='+r);
        }
        console.log('responses');
        console.log(responses);

        // Calculate answers
        let a = [];

        // q1
        let a1 = Math.abs(q/p);
        if(elasticity_type=='price' && question_type=='demand'){
            a1 = -a1;
        }
        if (elasticity_type == 'other'){
            if ([5, 6, 7, 8, 13, 14, 15, 16].includes(qq[stage-1][3])){
                a1 = -a1;
            }
        }
        else if (elasticity_type == 'total'){
            if ([1, 2, 3, 4, 5, 7, 9, 11, 34, 36, ,38, 40,  ].includes(qq[stage-1][2])) {
                a1 = 'up';
            }
            else if ([6, 8, 10, 12, 29, 30, 31, 32, 33, 35, 37, 39,  ].includes(qq[stage-1][2])) {
                a1 = 'down';
            }
            else if ([13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28].includes(qq[stage-1][2])) {
                a1 = 'inelastic';
            }
            else if ([41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56 ].includes(qq[stage-1][2])) {
                a1 = 'elastic';
            }
            else if ([57, 58, 59, 60, 61, 62 ].includes(qq[stage-1][2])) {
                a1 = 'same';
            }
            else if ([63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78].includes(qq[stage-1][2])) {
                a1 = 'unit elastic';
            }
        }

        console.log('a1='+a1);
        // a1 = Math.round( a1 * 10 ) / 10;
        a.push([a1]);

        // q2
        let a2;

        if (elasticity_type != 'total'){
            if (elasticity_type == 'price'){
                if (Math.abs(a1) == Infinity){
                    a2 = 'perfectly elastic';
                } else if (Math.abs(a1)==0){
                    a2 = 'perfectly inelastic';
                } else if (Math.abs(a1) < 1){
                    a2 = 'relatively inelastic';
                } else if (Math.abs(a1) == 1){
                    a2 = 'unit elastic';
                } else if (Math.abs(a1) > 1){
                    a2 = 'relatively elastic';
                }
            }
            else if (elasticity_type == 'other'){
                if ([1, 2, 3, 4].includes(qq[stage-1][3])){
                    a2 = 'substitutes';
                } else if ([5, 6, 7, 8].includes(qq[stage-1][3])){
                    a2 = 'complements';
                } else if ([9, 10, 11, 12].includes(qq[stage-1][3])){
                    a2 = 'normal good';
                } else if ([13, 14, 15, 16].includes(qq[stage-1][3])){
                    a2 = 'inferior good';
                } else if ([17, 18, 19, 20].includes(qq[stage-1][3])) {
                    a2 = 'necessity good';
                } else if ([21, 22, 23, 24].includes(qq[stage-1][3])) {
                    a2 = 'luxury good';
                }
            }
            a.push([a2]);
        }


        // check the answers
        for (let i=0; i<responses.length; i++){

            let correct = true;

            // test whether two sets contain the same values; useful here due to needing to compare arrays of names

            let a1_rounded;
            if (i==0){
                if (elasticity_type != 'total'){
                    a1_rounded = [Math.round( a1 * 10 ) / 10];
                    let r = [Math.round( responses[0] * 10 ) / 10];
                    correct = areArraysEqualSets(a1_rounded, r);
                } else {
                    correct = areArraysEqualSets(a[i], responses[i]);
                }

            } else {
                correct = areArraysEqualSets(a[i], responses[i]);
            }
            console.log(correct);
            console.log('min_q ' + min_q)
            if (correct){
                score++;
                scores[i] = 1;
                $('#q'+(min_q + offset + i)+'_grademark').addClass('correct');
                $('#q'+(min_q + offset + i)+'_grademark').html('&nbsp;\u2713');
            } else {
                scores[i] = 0;
                $('#q'+(min_q + offset + i)+'_grademark').addClass('incorrect');
                $('#q'+(min_q + offset + i)+'_grademark').html('&nbsp;\u2717');

                if (scoring_mode == 'practice'){
                    // Display correct answer
                    let feedback;

                    if (elasticity_type != 'total'){
                        if ([1].includes(min_q + offset + i)){
                            feedback = a1_rounded;
                        } else {
                            feedback = a[i];
                        }
                    } else{
                        console.log('a[i] = ' + a[i]);
                        feedback = a[i];
                        feedback = $("#q1 option[value='"+a[i]+"']").text();
                        console.log('feedback = ' + feedback);
                    }


                    let q_num = min_q + offset + i;
                    $('#q'+(q_num)+'_feedback').html(feedback);
                    $('#q'+(q_num)+'_hint').html(get_hint(i));

                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////
        //
        // SCORM STUFF BE HERE
        //
        // The code below is responsible for passing student responses to the LMS
        //
        //////////////////////////////////////////////////////////////////////////////////////////////////


        // record score if completed
        if (stage == num_stages){
            pipwerks.SCORM.data.set('cmi.completion_status', 'completed');
            pipwerks.SCORM.data.set('cmi.success_status', 'passed');
            if (scoring_mode == 'practice'){
                pipwerks.SCORM.data.set('cmi.score.raw', 1);
                pipwerks.SCORM.data.set('cmi.score.scaled', 1);
            }
            if (scoring_mode == 'quiz'){
                pipwerks.SCORM.data.set('cmi.score.raw', score);
                pipwerks.SCORM.data.set('cmi.score.scaled', score/max_score);
            }
        }

        let progress = stage/num_stages;
        pipwerks.SCORM.data.set('cmi.progress_measure', progress.toString());

        let txt;
        let scorm_var;

        // Capture the stimuli displayed on screen.
        // icollege has a 250 character limit on the description field,
        // so collect the initial point of each vector along with
        // the p and q deltas, and this will allow us to succinctly
        // record the information shown in the graph/table
        // (since the functions are linear).

        let description_details = "";

        let timestamp = get_scorm_timestamp(stage_start_time);

        // log elapsed session time
        let current_time = new Date();
        let session_elapsed_seconds = Math.floor((current_time - session_start_time) / 1000);
        //create the SCORM timespan format (using only seconds to keep things simple)
        txt = 'PT' + session_elapsed_seconds.toString() + 'S';
        pipwerks.SCORM.data.set('cmi.session_time', txt);

        // another SCORM variable to capture the length of time the questions were on screen
        let stage_elapsed_seconds = Math.floor((current_time - stage_start_time) / 1000);
        let latency = 'PT' + stage_elapsed_seconds.toString() + 'S';

        for (let i=0; i<responses.length; i++){
            let r_len = a[i].length;

            let n = pipwerks.SCORM.data.get('cmi.interactions._count');

            scorm_var = 'cmi.interactions.n.id'.replace('.n.', '.'+n.toString()+'.');
            pipwerks.SCORM.data.set(scorm_var, 's' + stage.toString() + '_q'+(i+min_q).toString());

            let response_type;
            if (i==0){
                response_type = 'numeric';
            } else if (i==1){
                response_type = 'fill-in';
            }

            scorm_var = 'cmi.interactions.n.type'.replace('.n.', '.'+n.toString()+'.');
            // if (r_len == 1){
            //     pipwerks.SCORM.data.set(scorm_var, 'numeric');
            // } else {
            //     pipwerks.SCORM.data.set(scorm_var, 'fill-in');
            // }
            pipwerks.SCORM.data.set(scorm_var, response_type);



            scorm_var = 'cmi.interactions.n.correct_responses.0.pattern'.replace('.n.', '.'+n.toString()+'.');
            // numeric answers must be in string format of min[:]max, even if single point
            txt ="";
            if (response_type == 'numeric'){
                // for numeric
                txt += a[i][0] + '[:]' + a[i][0];
            } else if (response_type == 'fill-in') {
                // for fill-in
                for (let j = 0; j < a[i].length; j++){
                    if (j==0){
                        txt += a[i][j].toString();
                    } else {
                        txt += '[,]' + a[i][j].toString();
                    }
                }
            }
            pipwerks.SCORM.data.set(scorm_var, txt);

            scorm_var = 'cmi.interactions.n.learner_response'.replace('.n.', '.'+n.toString()+'.');
            txt ="";
            if (responses[i].length == 1){
                txt += responses[i].toString()
            } else {
                for (let j = 0; j < responses[i].length; j++){
                    if (j==0){
                        txt += responses[i][j].toString();
                    } else {
                        txt += '[,]' + responses[i][j].toString();
                    }
                }
            }
            pipwerks.SCORM.data.set(scorm_var, txt);


            scorm_var = 'cmi.interactions.n.result'.replace('.n.', '.'+n.toString()+'.');
            pipwerks.SCORM.data.set(scorm_var, scores[i]);

            // need to get txt within 250 characters, so reduce string length as much as possible.
            txt = "";
            txt += qq[stage-1][0];
            txt += '; ';
            txt += qq[stage-1][i+1];
            scorm_var = 'cmi.interactions.n.description'.replace('.n.', '.'+n.toString()+'.');
            pipwerks.SCORM.data.set(scorm_var, txt);

            scorm_var = 'cmi.interactions.n.timestamp'.replace('.n.', '.'+n.toString()+'.');
            pipwerks.SCORM.data.set(scorm_var, timestamp);

            scorm_var = 'cmi.interactions.n.latency'.replace('.n.', '.'+n.toString()+'.');
            pipwerks.SCORM.data.set(scorm_var, latency);

        }

        ///////////////////////////////////////////////////////////
        //
        // SCORM stuff ends
        //
        ///////////////////////////////////////////////////////////



    }


    $("#submit").on( "click", function(){
        table_active = false;
        $(this).prop('disabled', true);
        $(this).removeClass('visible');
        $(this).addClass('invisible');

        // for (let s=1; s<=substage; s++){
        //     $('.substage' + s + ' input').prop('disabled', true);
        //     $('.substage' + s + ' select').prop('disabled', true);
        // }

        $('.target').prop('disabled', true);

        // $('#myTable').removeClass('table-hover');

        // let results = check_answers();
        check_answers();
        // if (results.num_incorrect > 0) {
        //     $('#submission_response').text(results.num_correct + ' correct and ' + results.num_incorrect + ' incorrect. Try again!');
        // } else {
        //     $('#submission_response').text('Correct, great job!');
        // }
        $('#btn_continue').addClass('visible');
        $('#btn_continue').removeClass('invisible');
    });

    function reset(){

        // $("#myTable > tbody > tr ").removeClass('border');
        // $('#myTable > tbody > tr > td:first-child').html(null);

        $( "#myTable").unbind( "click" );
        // $('[class*="substage"]').remove();

        // remove all divs that were inserted by draw_screen
        $('#question_div').nextAll('div').remove();


        $('#btn_repeat, #btn_finished').removeClass('visible');
        $('#btn_repeat, #btn_finished').addClass('invisible');
        $("#submit").addClass('btn-primary');
        $("#submit").removeClass('btn-secondary');
        $("#submit").addClass('visible');
        $("#submit").removeClass('invisible');

        $('.target').prop('disabled', false);
        $('.target').val(null);


        $('[id*=_grademark]').removeClass('incorrect correct');
        $('[id*=_grademark]').html('');
        $('[id*=_feedback]').html('');

        $('#myTable').addClass('table-hover');

        $('#myTable tr').remove();


        col_a_header = '';
        col_b_header = '';
        col_c_header = '';
        col_d_header = '';
        col_e_header = '';
        col_f_header = '';
        col_g_header = '';

        column_a = [];
        column_b = [];
        column_c = [];
        column_d = [];
        column_e = [];
        column_f = [];
        column_g = [];

        data = []
        responses = [];

        table_active = false;
    }

    // function increment_substage(){
    //     substage++;
    //
    //     $('section > .substage'+substage).show();
    //
    //     if (substage==1){
    //         // $('.substage3 .target').prop('disabled', false);
    //         // if (question_type == 'opportunity'){
    //         //     $('.substage3').not('.advantage').show();
    //         // } else {
    //         //     $('.substage3').show();
    //         // }
    //         $("#submit").addClass('visible');
    //         $("#submit").removeClass('invisible');
    //         $("#btn_continue").addClass('invisible');
    //         $("#btn_continue").removeClass('visible');
    //     }
    //
    //
    //     $('table tr').removeClass('table-active');
    //
    //     if (change_mode == 'nochanges'){
    //         table_active = true;
    //     } else if (change_mode == 'changes'){
    //         if (substage == 2 || substage == 3){
    //             table_active = true;
    //         }
    //     }
    //     $("#submit").addClass('visible');
    //     $("#submit").removeClass('invisible');
    //     $("#btn_continue").addClass('invisible');
    //     $("#btn_continue").removeClass('visible');
    // }

    document.addEventListener( 'DOMContentLoaded', function() {


        session_start_time = new Date();

        pipwerks.SCORM.connection.initialize();

        student_id = pipwerks.SCORM.data.get('cmi.learner_id');
        student_name = pipwerks.SCORM.data.get('cmi.learner_name');

        let entry = pipwerks.SCORM.data.get('cmi.entry');

        let progress = pipwerks.SCORM.data.get('cmi.progress_measure');

        let threshold = pipwerks.SCORM.data.get('cmi.completion_threshold');

        let completion_status = pipwerks.SCORM.data.get('cmi.completion_status');

        if (progress == 1 && scoring_mode == 'quiz'){
            block_participation();
            return;
        }

        start_sequence();

        $('#btn_finished').click(function () {
            $('section, button').addClass('invisible');
            $('section, button').removeClass('visible');
            $('.center_container').show();

            pipwerks.SCORM.data.set('cmi.exit', 'normal');
            pipwerks.SCORM.connection.terminate();
        });

        $('#btn_continue').click(function () {
            if (stage == 0){
                draw_screen();
                return;
            }
            // else if ( substage < 4){
            //     increment_substage();
            //     return;
            // }
            else if (stage == num_stages){
                ending();
                return;
            }
            reset();
            draw_screen();
        });


        $('#btn_repeat').click(function () {
            reset();
            start_sequence();
        });

        jQuery(window).bind('beforeunload', function(e) {
            // if (stage==num_stages){
            //     pipwerks.SCORM.data.set('cmi.exit', 'normal');
            // } else {
            //     pipwerks.SCORM.data.set('cmi.exit', 'suspend');
            // }
            pipwerks.SCORM.data.set('cmi.exit', 'normal');
            let t = pipwerks.SCORM.connection.terminate();
            // return true;
        });

    });


</script>